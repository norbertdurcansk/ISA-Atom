#ifndef Timefun_HPP
#define Timefun_HPP
#include "arfeed.hpp"

//count max time function
int News(entry *); 

#endif